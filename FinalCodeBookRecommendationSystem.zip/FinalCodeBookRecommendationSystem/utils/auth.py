import streamlit as st
import json

def load_users():
    try:
        with open("users.json", "r") as file:
            users = json.load(file)
    except FileNotFoundError:
        users = {}
    return users

def save_users(users):
    with open("users.json", "w") as file:
        json.dump(users, file)

def login():
    st.title("Login")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")
    if st.button("Login"):
        users = load_users()
        if username in users and users[username]["password"] == password:
            st.success("Logged in successfully!")
            return username
        else:
            st.error("Invalid username or password")
    return None

def signup():
    st.title("Sign Up")
    username = st.text_input("Username")
    password = st.text_input("Password", type="password")
    confirm_password = st.text_input("Confirm Password", type="password")
    genres = st.multiselect("Favorite Genres", ["Fiction", "Non-Fiction", "Mystery", "Science Fiction", "Romance"])
    if st.button("Sign Up"):
        if password == confirm_password:
            users = load_users()
            if username not in users:
                users[username] = {"password": password, "genres": genres, "rated_books": {}}
                save_users(users)
                st.success("Account created successfully!")
            else:
                st.error("Username already exists")
        else:
            st.error("Passwords do not match")

def update_profile(username):
    st.title("Update Profile")
    users = load_users()
    user = users[username]
    genres = st.multiselect("Favorite Genres", ["Fiction", "Non-Fiction", "Mystery", "Science Fiction", "Romance"], default=user["genres"])
    if st.button("Update"):
        user["genres"] = genres
        save_users(users)
        st.success("Profile updated successfully!")

def rate_book(username, book_title, rating):
    users = load_users()
    user = users[username]
    user["rated_books"][book_title] = rating
    save_users(users)


