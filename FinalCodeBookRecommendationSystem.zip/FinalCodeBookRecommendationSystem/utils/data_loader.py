import pandas as pd

def load_data():
    books = pd.read_csv('data/books.csv', on_bad_lines='skip')
    ratings = pd.read_csv('data/Ratings.csv')
    books.rename(columns={'Image-URL-L;;;;;;': 'Image-URL-L'}, inplace=True)
    books_ratings = pd.merge(books, ratings, on='ISBN')

    n = 250
    top_n = books_ratings["Book-Title"].value_counts().index[:n]
    books_ratings_ = books_ratings[books_ratings['Book-Title'].isin(top_n)]

    return books_ratings_