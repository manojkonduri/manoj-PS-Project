import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer

def find_similar_books(book, books_ratings_):
    df_books_ = pd.pivot_table(books_ratings_, values=['Book-Rating'], index=['Book-Title', 'User-ID'], aggfunc=np.mean).unstack()
    df_books_ = df_books_.fillna(0)
    cosine_sim = cosine_similarity(df_books_)
    cosine_sim_df = pd.DataFrame(cosine_sim, index=df_books_.index, columns=df_books_.index)
    selected_book = [book]
    books_summed = np.sum(cosine_sim_df[selected_book], axis=1)
    books_summed = books_summed.sort_values(ascending=False)
    ranked_books = books_summed.index.tolist()
    return ranked_books[1:6]

def find_nonsimilar_books(book, books_ratings_):
    df_books_ = pd.pivot_table(books_ratings_, values=['Book-Rating'], index=['Book-Title', 'User-ID'], aggfunc=np.mean).unstack()
    df_books_ = df_books_.fillna(0)
    cosine_sim = cosine_similarity(df_books_)
    cosine_sim_df = pd.DataFrame(cosine_sim, index=df_books_.index, columns=df_books_.index)
    selected_book = [book]
    books_summed = np.sum(cosine_sim_df[selected_book], axis=1)
    books_summed = books_summed.sort_values(ascending=True)
    ranked_books = books_summed.index.tolist()
    return ranked_books[:5]

def get_recommendations(book, books_ratings_, books_ratings_new, top_n):
    books_ratings_new['Attributes'] = books_ratings_new['Book-Author'] + ' ' + books_ratings_new['Publisher']
    books_ratings_new.dropna(subset='Book-Author', inplace=True)
    books_ratings_new.dropna(subset='Publisher', inplace=True)
    books_ratings_new.reset_index(drop=True, inplace=True)
    books_ratings_new_ = books_ratings_new[books_ratings_new['Book-Title'].isin(top_n)]
    _books_ratings_ = books_ratings_new_.drop_duplicates(subset='Book-Title', keep="first")
    tfidf = TfidfVectorizer(stop_words='english')
    tfidf_matrix = tfidf.fit_transform(_books_ratings_['Attributes'])
    cosine_simm = cosine_similarity(tfidf_matrix)
    _books_ratings_.reset_index(drop=True, inplace=True)
    indices = pd.Series(_books_ratings_.index, index=_books_ratings_['Book-Title'])
    idx = indices[book]
    sim_scores = list(enumerate(cosine_simm[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    sim_scores = sim_scores[1:6]
    book_indices = [i[0] for i in sim_scores]
    return (_books_ratings_['Book-Title'].iloc[book_indices]).tolist()