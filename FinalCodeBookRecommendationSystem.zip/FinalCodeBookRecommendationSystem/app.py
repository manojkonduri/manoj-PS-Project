import streamlit as st
from utils.data_loader import load_data
from utils.recommender import find_similar_books, find_nonsimilar_books, get_recommendations
from utils.auth import login, signup, update_profile, rate_book

def truncate(m, decimals=0):
    multiplier = 10 ** decimals
    return int(m * multiplier) / multiplier

def main():
    books_ratings_ = load_data()

    # Authentication
    if "logged_in_user" not in st.session_state:
        st.session_state.logged_in_user = None

    if not st.session_state.logged_in_user:
        st.sidebar.title("Authentication")
        menu = ["Login", "Sign Up"]
        choice = st.sidebar.radio("Go to", menu)

        if choice == "Login":
            username = login()
            if username:
                st.session_state.logged_in_user = username
        elif choice == "Sign Up":
            signup()
    else:
        st.sidebar.title(f"Welcome, {st.session_state.logged_in_user}!")
        menu = ["Recommendations", "Profile", "Rate a Book"]
        choice = st.sidebar.radio("Go to", menu)

        if choice == "Recommendations":
            st.title('What to Read Next?')

            book = st.selectbox('Choose the book you are currently reading', books_ratings_['Book-Title'].unique())

            # Display selected book details
            selected_book = books_ratings_[books_ratings_['Book-Title'] == book].iloc[0]
            st.write(f"## {selected_book['Book-Title']}")
            col1, mid, col2, mid, col3 = st.columns([10, 1, 10, 1, 10])
            with col1:
                st.image(selected_book['Image-URL-M'], width=139)
            with col2:
                st.write(selected_book['Book-Author'])
                st.write(selected_book['Publisher'])
                st.text(selected_book['Year-Of-Publication'])
                st.text(selected_book['ISBN'])
            with col3:
                st.write('Rating:')
                st.success(truncate(selected_book['Book-Rating'], 2))

            # Collaborative Filtering Recommendations
            alg = st.selectbox('Show results as', ('Author & Publisher', 'Most similar according to voters', 'Least similar according to voters'))
            if alg == 'Author & Publisher':
                st.title('Take a Look:')
                list2 = get_recommendations(book, books_ratings_, books_ratings_, books_ratings_["Book-Title"].value_counts().index[:250])
            elif alg == 'Most similar according to voters':
                st.title('Take a Look:')
                list2 = find_similar_books(book, books_ratings_)
            else:
                st.title('Take a Look:')
                list2 = find_nonsimilar_books(book, books_ratings_)
            for b in list2:
                recommended_books = books_ratings_[books_ratings_['Book-Title'] == b]
                if not recommended_books.empty:
                    recommended_book = recommended_books.iloc[0]
                    st.write(f"## {recommended_book['Book-Title']}")
                    col1, mid, col2, mid, col3 = st.columns([10, 1, 10, 1, 10])
                    with col1:
                        st.image(recommended_book['Image-URL-M'], width=139)
                    with col2:
                        st.write(recommended_book['Book-Author'])
                        st.write(recommended_book['Publisher'])
                        st.text(recommended_book['Year-Of-Publication'])
                        st.text(recommended_book['ISBN'])
                    with col3:
                        st.write('Rating:')
                        st.success(truncate(recommended_book['Book-Rating'], 2))

        elif choice == "Profile":
            update_profile(st.session_state.logged_in_user)

        elif choice == "Rate a Book":
            st.title("Rate a Book")
            book_title = st.selectbox("Select a book to rate", books_ratings_["Book-Title"].unique())
            rating = st.slider("Rating", min_value=1, max_value=5, step=1)
            if st.button("Submit Rating"):
                rate_book(st.session_state.logged_in_user, book_title, rating)
                st.success("Rating submitted successfully!")

        logout_button = st.sidebar.button("Logout")
        if logout_button:
            st.session_state.logged_in_user = None
            st.experimental_rerun()

if __name__ == "__main__":
    main()